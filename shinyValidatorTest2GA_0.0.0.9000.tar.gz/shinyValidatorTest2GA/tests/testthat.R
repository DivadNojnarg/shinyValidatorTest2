library(testthat)
library(shinyValidatorTest2GA)

test_check("shinyValidatorTest2GA")
